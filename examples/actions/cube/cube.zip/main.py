import sys
import json

def main(param):
    x = param['x']
    return {'CubeResult': x * x * x}
