import sys
import json

def main(param):
    x = param['x']
    y = param['y']
    return {'AddResult': x + y}
