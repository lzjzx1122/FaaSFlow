import json
import random

def main(param):
    return {'RandomResult': random.randrange(0, 10)}
